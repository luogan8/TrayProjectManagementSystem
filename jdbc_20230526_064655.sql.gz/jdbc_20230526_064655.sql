-- MySQL dump 10.13  Distrib 5.5.62, for Linux (x86_64)
--
-- Host: localhost    Database: jdbc
-- ------------------------------------------------------
-- Server version	5.5.62-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tray_enterlog`
--

DROP TABLE IF EXISTS `tray_enterlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tray_enterlog` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `number` int(11) NOT NULL DEFAULT '0',
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tray_enterlog`
--

LOCK TABLES `tray_enterlog` WRITE;
/*!40000 ALTER TABLE `tray_enterlog` DISABLE KEYS */;
INSERT INTO `tray_enterlog` VALUES (27,'2023-05-21 14:42:00','Anman','通用Tray',1240,'R2'),(28,'2023-05-26 10:09:00','ELM','通用Tray',1023,'');
/*!40000 ALTER TABLE `tray_enterlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tray_info`
--

DROP TABLE IF EXISTS `tray_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tray_info` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `tray_name` varchar(255) NOT NULL DEFAULT '',
  `tray_type` varchar(255) NOT NULL DEFAULT '0',
  `tray_number` varchar(255) NOT NULL DEFAULT '',
  `tray_inside` int(11) NOT NULL DEFAULT '0',
  `tray_outside` int(11) NOT NULL DEFAULT '0',
  `deleted` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=3963 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tray_info`
--

LOCK TABLES `tray_info` WRITE;
/*!40000 ALTER TABLE `tray_info` DISABLE KEYS */;
INSERT INTO `tray_info` VALUES (3804,'Max','平贴','C00008472',0,0,0),(3805,'Max','切割','C00008473',0,0,0),(3806,'Max','3D贴合','C00008474',0,0,0),(3807,'Max','CGTray','C00008475',0,0,0),(3808,'Eagle','通用Tray','C00029976',0,0,0),(3809,'Eagle','CGTray','C00032270',0,0,0),(3810,'Phoenix','通用Tray','C00035922',0,0,0),(3811,'Phoenix','CGTray','C00034933',0,0,0),(3812,'Nadia','平贴','C00038323',0,0,0),(3813,'Nadia','3D贴合','C00038324',0,0,0),(3814,'Nadia','CGTray','C00038325',0,0,0),(3815,'Jewel','CGTray','C00041128',0,3060,0),(3816,'Jewel','切割','C00046170',0,1465,0),(3817,'Jewel','通用Tray','C00041127',0,1156,0),(3818,'Columbus','CGTray','C00049374',200,0,0),(3819,'Columbus','通用Tray','C00042273',266,0,0),(3820,'Leap','通用Tray','C00039828',0,0,0),(3821,'Leap','CGTray','C00039827',0,0,0),(3822,'Leap','PBC下料Tray','C00073153',0,0,0),(3823,'Venice','CGTray','C00038099',0,2520,0),(3824,'Bravo','CGTray','C00046554',0,0,0),(3825,'Summer','平贴','C00046935',1720,0,0),(3826,'Summer','3D贴合','C00046934',4085,0,0),(3827,'Summer','绑定','C00046933',1418,0,0),(3828,'Summer','CGTray','C00060597',0,0,0),(3829,'Summer','切割','C00046932',4819,0,0),(3830,'Sirius','CGTray','C00050239',1269,1680,0),(3831,'Sirius','通用Tray','C00050313',1051,7310,0),(3832,'Sirius','切割','C00051393',0,1680,0),(3833,'Sirius','绑定','C00050336',103,2108,0),(3834,'Yala','通用Tray','C00051350',11579,3360,0),(3835,'Yala','CGTray','C00051351',5167,1680,0),(3836,'Yala','POL下料Tray','C00070173',928,0,0),(3837,'Zurich','通用Tray','C00051627',0,1080,0),(3838,'Zurich','CGTray','C00051626',2932,2040,0),(3839,'Berlin','CGTray','C00052791',0,0,0),(3840,'Berlin','通用Tray','C00052790',0,0,0),(3841,'Berlin','切割','C00060079',0,0,0),(3842,'Berlin','POL下料Tray','C00058937',0,0,0),(3843,'通用平Tray','平贴','C00018601',0,2843,0),(3844,'Milan','CGTray','C00053403',4147,840,0),(3845,'Milan','通用Tray','C00053402',668,4445,0),(3846,'Milan','切割','C00060078',0,1322,0),(3847,'Milan','IC','C00076233',500,0,0),(3848,'Polaris','通用Tray','C00055379',0,0,0),(3849,'Polaris','CGTray','C00055378',0,0,0),(3850,'Polaris','切割','C00055380',0,0,0),(3851,'Davos','通用Tray','C00056256',0,1146,0),(3852,'Davos','CGTray','C00056257',0,0,0),(3853,'Navy','通用Tray','C00058159',0,0,0),(3854,'Navy','CGTray','C00058160',0,0,0),(3855,'Navy','POL下料Tray','C00061609',0,0,0),(3856,'Ginkgo','组装Tray','C00057660',0,0,0),(3857,'Ginkgo','组装Tray1','C00057661',0,0,0),(3858,'Lisbon','组装Tray','C00058402',0,0,0),(3859,'Dubai','通用Tray','C00061563',0,420,0),(3860,'Doha','通用Tray','C00061455',7521,0,0),(3861,'Doha','POL下料Tray','C00061841',2260,1320,0),(3862,'Cario','通用Tray','C00061251',507,306,0),(3863,'Cario','切割','C00070655',0,714,0),(3864,'Cario','CGTray','C00061252',0,150,0),(3865,'Maple','通用Tray','C00062054',0,0,0),(3866,'Maple','POL下料Tray','C08872746',0,0,0),(3867,'Legend','平贴','C00062115',78,2855,0),(3868,'Legend','CGTray','C00056019',295,1873,0),(3869,'Legend','通用Tray','C00056020',3258,2650,0),(3870,'Fir','通用Tray','C00067947',1375,500,0),(3871,'Fir','CGTray','C00070172',818,0,0),(3872,'Fir','POL下料Tray','C00070171',386,0,0),(3873,'COCO','绑定上料Tray','C00069464',1675,0,0),(3874,'COCO','切割','C00069463',219,665,0),(3875,'COCO','绑定下料Tray','C00069465',2649,315,0),(3876,'COCO','3D贴合','C00069461',4886,0,0),(3877,'COCO','保护膜下料Tray','C00069466',0,0,0),(3878,'COCO','OCA下料Tray','C00069462',613,0,0),(3879,'COCO','CGTray','C00069519',1705,2065,0),(3880,'COCO','BKT上料','C00081384',1032,0,0),(3881,'YAYA','POL下料Tray','C00070173',2,0,0),(3882,'YEW','通用Tray','C00070281',14249,0,0),(3883,'YEW','CGTray','C00070283',7737,840,0),(3884,'YEW','POL下料Tray','C00070282',2780,0,0),(3885,'YEW','切割','C00074804',2224,1680,0),(3886,'Aging','','C00070198',1460,0,0),(3887,'Elm','POL下料Tray','C00071650',3730,0,0),(3888,'Elm','通用Tray','C00071652',24031,0,0),(3889,'Elm','CGTray','C00071651',10133,0,0),(3890,'Elm','切割','C00071882',2782,1680,0),(3891,'Elm-C','贴合脱泡Tray','C00082106',1269,0,0),(3892,'Bern','POL下料Tray','C00072762',0,0,0),(3893,'Bern','绑定','C00072763',0,0,0),(3894,'Amber','PBC下料Tray','C00072908',765,0,0),(3895,'Amber','CGTray','C00072764',1451,0,0),(3896,'Amber','切割','C00072909',1352,0,0),(3897,'Amber','3D贴合','C00072917',0,0,0),(3898,'Amber','平贴','C00072765',1857,0,0),(3899,'Amber','2.5D贴合','C00075058',2702,351,0),(3900,'SKY','通用Tray','C00073067',5817,0,0),(3901,'SKY','CGTray','C00073066',3042,71,0),(3902,'SKY','PBC下料Tray','C00073068',1205,0,0),(3903,'Tiger','平贴','C00012904',0,7465,0),(3904,'Tiger','CGTray','C00012907',0,2621,0),(3905,'Tiger','切割','C00012905',364,2575,0),(3906,'Tiger','3D贴合','C00037596',0,3700,0),(3907,'Tiger','脱泡专用','C00073934',0,1640,0),(3908,'Poplar','通用Tray','C00048554',0,0,0),(3909,'Poplar','平贴','C00052982',0,0,0),(3910,'Poplar','CGTray','C00052983',0,0,0),(3911,'COCOnut','切割','C00071003',0,0,0),(3912,'COCOnut','POL下料Tray','C00071002',0,0,0),(3913,'COCOnut','OLB上料','C00071001',0,0,0),(3914,'COCOnut-S','3D贴合','C00071411',0,0,0),(3915,'COCOnut-L','3D贴合','C00071230',0,0,0),(3916,'COCOnut-S','CGTray','C00071409',0,0,0),(3917,'COCOnut-L','CGTray','C00071163',0,0,0),(3918,'COCOnut-S','组装Tray','C00071407',0,0,0),(3919,'COCOnut-L','组装Tray','C00071164',0,0,0),(3920,'Cedar','通用Tray','C00049716',0,0,0),(3921,'Cedar','CGTray','C00051403',0,0,0),(3922,'Mecca','3D贴合','C00077244',587,340,0),(3923,'Willow','指纹Tray','C00077089',688,0,0),(3924,'Willow','IC','C00077090',700,0,0),(3925,'Bamboo','指纹Tray','C00077091',345,1005,0),(3926,'Holly-L','3D贴合','C00077308',105,1075,0),(3927,'Holly-L','CGTray','C00077060',0,0,0),(3928,'Holly-L','组装Tray','C00077307',0,0,0),(3929,'Holly','OLB上料','C00077061',0,0,0),(3930,'Holly','切割','C00077309',0,100,0),(3931,'Holly','POL下料Tray','C00077062',0,0,0),(3932,'Holly-S','CGTray','C00077059',58,392,0),(3933,'Holly-S','3D贴合','c00077306',0,0,0),(3934,'Holly-S','组装Tray','C00077305',0,0,0),(3935,'Anman','POL下料Tray','C00077190',1215,752,0),(3936,'Anman','通用Tray','C00077191',4345,2084,0),(3937,'Anman','CGTray','C00077192',2824,640,0),(3938,'Koln','通用Tray','C00067172',832,1840,0),(3939,'Koln','CGTray','C00067173',1945,175,0),(3940,'Elm-E','通用Tray','C00080339',7723,0,0),(3941,'Elm-E','CGTray','C00080338',3459,0,0),(3942,'Bali','通用Tray','C00080655',3429,0,0),(3943,'Bali','PBC下料Tray','C00080654',1207,0,0),(3944,'Bali','CGTray','C00080656',2316,0,0),(3945,'Jewel-T','通用Tray','C00080823',769,0,0),(3946,'Jewel-T','CGTray','C00080821',478,0,0),(3947,'Jewel-T','切割','C00080822',474,0,0),(3948,'Jewel-T','PBC下料Tray','C00080820',480,0,0),(3949,'Leeds','通用Tray','C00081635',5336,0,0),(3950,'Leeds','CGTray','C00081636',3466,0,0),(3951,'Leeds','PBC下料Tray','C00081632',1275,0,0),(3952,'Leeds','A-Lami下料Tray','C00081633',999,0,0),(3953,'Sana','绑定下料Tray','C00082343',500,0,0),(3954,'Sana','CGTray','C00082346',499,0,0),(3955,'Sana','3D贴合','C00082344',745,0,0),(3956,'Sana','PBC下料Tray','C00082348',497,0,0),(3957,'Sana','切割','C00082799',750,0,0),(3958,'Sana','OCA下料Tray','C00082345',496,0,0),(3959,'通用','CGTray','C00081603',100,0,0),(3960,'Wood','TGP下料Tray','C00083429',300,0,0),(3961,'Oak','CGTray','C00084225',555,0,0),(3962,'Oak','通用Tray','C00084223',832,0,0);
/*!40000 ALTER TABLE `tray_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tray_nglog`
--

DROP TABLE IF EXISTS `tray_nglog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tray_nglog` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `number` varchar(255) NOT NULL DEFAULT '',
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tray_nglog`
--

LOCK TABLES `tray_nglog` WRITE;
/*!40000 ALTER TABLE `tray_nglog` DISABLE KEYS */;
INSERT INTO `tray_nglog` VALUES (9,'2023-05-21 14:43:00','Anman','通用Tray','1240','R2'),(10,'2023-05-25 08:53:00','OAK','通用Tray','3',''),(11,'2023-05-25 08:53:00','Anman','通用Tray','24',''),(12,'2023-05-25 08:53:00','Yew','通用Tray','151',''),(13,'2023-05-25 08:53:00','Anman','POL下料Tray','17',''),(14,'2023-05-25 08:53:00','Yew','POL下料Tray','4',''),(15,'2023-05-25 08:53:00','Yew','CGTray','174',''),(16,'2023-05-25 08:53:00','Yew','切割','14',''),(17,'2023-05-25 08:53:00','Summer','3D贴合','82',''),(18,'2023-05-25 08:53:00','Summer','绑定','19',''),(19,'2023-05-25 08:53:00','Summer','切割','3',''),(20,'2023-05-25 08:53:00','Summer','平贴','10',''),(21,'2023-05-25 08:53:00','Poplar','通用Tray','16',''),(22,'2023-05-25 08:53:00','Elm','通用Tray','129',''),(23,'2023-05-25 08:53:00','Elm','CGTray','204',''),(24,'2023-05-25 08:53:00','Elm','POL下料Tray','9',''),(25,'2023-05-25 08:53:00','Elm','切割','54',''),(26,'2023-05-25 08:53:00','Elm','IC','3',''),(27,'2023-05-25 08:53:00','COCO','OCA下料Tray','9',''),(28,'2023-05-25 08:53:00','COCO','切割','12',''),(29,'2023-05-25 08:53:00','COCO','BKT上料','55',''),(30,'2023-05-25 08:53:00','COCO','3D贴合','29',''),(31,'2023-05-25 08:53:00','COCO','绑定上料Tray','9',''),(32,'2023-05-25 08:53:00','COCO','绑定下料Tray','5',''),(33,'2023-05-25 08:53:00','COCO','CGTray','11',''),(34,'2023-05-25 08:53:00','ELM-E','CGTray','11',''),(35,'2023-05-25 08:53:00','ELM-E','通用Tray','84',''),(36,'2023-05-25 08:53:00','Doha','通用Tray','11',''),(37,'2023-05-25 08:53:00','Doha','POL下料Tray','11',''),(38,'2023-05-25 08:53:00','ELM-C','贴合脱泡Tray','8',''),(39,'2023-05-25 08:53:00','Zurich','通用Tray','1',''),(40,'2023-05-25 08:53:00','Zurich','CGTray','69',''),(41,'2023-05-25 08:53:00','Mecca','3D贴合','2',''),(42,'2023-05-25 08:53:00','Tiger','平贴','9',''),(43,'2023-05-25 08:53:00','Tiger','切割','1',''),(44,'2023-05-25 08:53:00','Leap','通用Tray','2',''),(45,'2023-05-25 08:53:00','Davos','通用Tray','1',''),(46,'2023-05-25 08:53:00','Cario','通用Tray','4',''),(47,'2023-05-25 08:53:00','Sky','通用Tray','21',''),(48,'2023-05-25 08:53:00','Sky','CGTray','8',''),(49,'2023-05-25 08:53:00','Amber','切割','1',''),(50,'2023-05-25 08:53:00','Amber','平贴','4',''),(51,'2023-05-25 08:53:00','Amber','PBC下料Tray','8',''),(52,'2023-05-25 08:53:00','Amber','CGTray','1',''),(53,'2023-05-25 08:53:00','Amber','2.5D贴合','2',''),(54,'2023-05-25 08:53:00','Yala','通用Tray','10',''),(55,'2023-05-25 08:53:00','Yala','CGTray','39',''),(56,'2023-05-25 08:53:00','Porto','通用Tray','2',''),(57,'2023-05-25 08:53:00','Porto','通用Tray','2',''),(58,'2023-05-25 08:53:00','Jewel','通用Tray','1',''),(59,'2023-05-25 08:53:00','Jewel','CGTray','2',''),(60,'2023-05-25 08:53:00','Berlin','CGTray','10',''),(61,'2023-05-25 08:53:00','Bali','通用Tray','5',''),(62,'2023-05-25 08:53:00','Bali','PBC下料Tray','3',''),(63,'2023-05-25 08:53:00','Sirius','通用Tray','1',''),(64,'2023-05-25 08:53:00','Sirius','绑定','1',''),(65,'2023-05-25 08:53:00','Leeds','通用Tray','2','');
/*!40000 ALTER TABLE `tray_nglog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tray_outside`
--

DROP TABLE IF EXISTS `tray_outside`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tray_outside` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `state` int(11) NOT NULL DEFAULT '0' COMMENT '0+ 1-',
  `number` int(11) NOT NULL DEFAULT '0',
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tray_outside`
--

LOCK TABLES `tray_outside` WRITE;
/*!40000 ALTER TABLE `tray_outside` DISABLE KEYS */;
INSERT INTO `tray_outside` VALUES (18,'2023-05-21 14:44:00','Anman','通用Tray',1,1240,'R2'),(19,'2023-05-22 14:19:00','COCO','绑定下料Tray',1,630,'R2'),(20,'2023-05-22 14:19:00','Leeds','通用Tray',1,1050,'R0'),(21,'2023-05-23 08:31:00','Amber','平贴',1,1000,''),(22,'2023-05-23 11:09:00','Leeds','通用Tray',1,1610,''),(23,'2023-05-25 15:43:00','COCO','绑定上料Tray',1,1015,'');
/*!40000 ALTER TABLE `tray_outside` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tray_user`
--

DROP TABLE IF EXISTS `tray_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tray_user` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `mail` varchar(255) NOT NULL DEFAULT '',
  `deleted` varchar(255) NOT NULL DEFAULT '0',
  `grade` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tray_user`
--

LOCK TABLES `tray_user` WRITE;
/*!40000 ALTER TABLE `tray_user` DISABLE KEYS */;
INSERT INTO `tray_user` VALUES (1,'10280080','17000009940','lognn@qq.com','0',1);
/*!40000 ALTER TABLE `tray_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tray_yard`
--

DROP TABLE IF EXISTS `tray_yard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tray_yard` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `state` int(11) NOT NULL DEFAULT '0',
  `number` int(11) NOT NULL DEFAULT '0',
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tray_yard`
--

LOCK TABLES `tray_yard` WRITE;
/*!40000 ALTER TABLE `tray_yard` DISABLE KEYS */;
/*!40000 ALTER TABLE `tray_yard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'jdbc'
--

--
-- Dumping routines for database 'jdbc'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-26  6:46:56
